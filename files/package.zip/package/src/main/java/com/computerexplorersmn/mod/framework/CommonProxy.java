package com.computerexplorersmn.mod.framework;

import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

import com.computerexplorersmn.mod.customize.CustomWorldGenerator;
import com.computerexplorersmn.mod.customize.ModBlocks;
import com.computerexplorersmn.mod.customize.ModItems;
import com.computerexplorersmn.mod.customize.ModRecipes;


/*DONT TOUCH THIS FILE, IT IS SET UP JUST THE WAY YOU NEED IT */

public class CommonProxy {

	public void preInit(FMLPreInitializationEvent e) {
		ModItems.createItems();
		ModBlocks.createBlocks();
		ModRecipes.initCrafting();
	}

	public void init(FMLInitializationEvent e) {
		 GameRegistry.registerWorldGenerator(new CustomWorldGenerator(), 0);
	}

	public void postInit(FMLPostInitializationEvent e) {

	}
}
