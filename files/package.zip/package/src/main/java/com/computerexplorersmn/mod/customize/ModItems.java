package com.computerexplorersmn.mod.customize;

import com.computerexplorersmn.mod.framework.Main;
import com.computerexplorersmn.mod.framework.items.BasicItem;
import com.computerexplorersmn.mod.framework.items.ItemModAxe;
import com.computerexplorersmn.mod.framework.items.ItemModBow;
import com.computerexplorersmn.mod.framework.items.ItemModHoe;
import com.computerexplorersmn.mod.framework.items.ItemModMultitool;
import com.computerexplorersmn.mod.framework.items.ItemModPickaxe;
import com.computerexplorersmn.mod.framework.items.ItemModSpade;
import com.computerexplorersmn.mod.framework.items.ItemModSword;
import com.computerexplorersmn.mod.framework.items.ModItemAdvancedFood;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.fml.common.registry.GameRegistry;

public final class ModItems {
	//STEP 1: Declare your Item here
	public static Item netherdiamond;
	public static Item magicBeans;
	
	public static Item netherdiamondpickaxe;
	public static Item netherdiamondaxe;
	public static Item netherdiamondshovel;
	public static Item netherdiamondhoe;
	public static Item netherdiamondsword;
	public static Item netherdiamondmultitool;
	
	public static Item netherdiamondbow;
	
	public static Item netherdiamondhelmet;
	public static Item netherdiamondchestplate;
	public static Item netherdiamondleggings;
	public static Item netherdiamondboots;
	
	//STEP 1.5, if you are making an Armor or Tool, Armor and Tool Material Definitions go here
	//ARMOR:																					name,	texture location, durability, armor values, enchantability
	public static ArmorMaterial NETHERDIAMONDARMOR = EnumHelper.addArmorMaterial("NETHERDIAMONDARMOR", "mod:netherdiamond", 40, new int[]{3, 8, 6, 3}, 30);
	
	//TOOLS:																	name, harvest level, durability, mining speed, damage, enchantability
	public static ToolMaterial NETHERDIAMONDTOOL = EnumHelper.addToolMaterial("NETHERDIAMONDTOOL", 3, 3000, 18.0F, 6.0F, 30);
	
	
	public static void createItems() {
		//STEP 2: Register your Item here
		GameRegistry.registerItem(netherdiamond = new BasicItem("netherdiamond"),"netherdiamond");

		GameRegistry.registerItem(magicBeans = new ModItemAdvancedFood("magicbeans", 1, 0.5f, false)
				.addPotionEffect(new PotionEffect(Potion.regeneration.id, 6000, 4), 0.1)
				.addPotionEffect(new PotionEffect(Potion.nightVision.id, 6000, 4), 0.1)
				.addPotionEffect(new PotionEffect(Potion.absorption.id, 6000, 4), 0.1)
				.addPotionEffect(new PotionEffect(Potion.digSpeed.id, 6000, 4), 0.1)
				.addPotionEffect(new PotionEffect(Potion.jump.id, 6000, 4), 0.1)
				.addPotionEffect(new PotionEffect(Potion.moveSpeed.id, 6000, 4), 0.1)
				.setAlwaysEdible(), "magicbeans");
		
		GameRegistry.registerItem(netherdiamondpickaxe = new ItemModPickaxe("netherdiamondpickaxe", NETHERDIAMONDTOOL), "netherdiamondpickaxe");
		GameRegistry.registerItem(netherdiamondaxe = new ItemModAxe("netherdiamondaxe", NETHERDIAMONDTOOL), "netherdiamondaxe");
		GameRegistry.registerItem(netherdiamondshovel = new ItemModSpade("netherdiamondshovel", NETHERDIAMONDTOOL), "netherdiamondshovel");
		GameRegistry.registerItem(netherdiamondhoe = new ItemModHoe("netherdiamondhoe", NETHERDIAMONDTOOL), "netherdiamondhoe");
		GameRegistry.registerItem(netherdiamondsword = new ItemModSword("netherdiamondsword", NETHERDIAMONDTOOL), "netherdiamondsword");
		GameRegistry.registerItem(netherdiamondmultitool = new ItemModMultitool("netherdiamondmultitool", NETHERDIAMONDTOOL), "netherdiamondmultitool");
		
		GameRegistry.registerItem(netherdiamondbow = new ItemModBow("netherdiamondbow"), "netherdiamondbow");
		
		GameRegistry.registerItem(netherdiamondhelmet = new ItemModArmor("netherdiamondhelmet", NETHERDIAMONDARMOR, 1, 0), "netherdiamondhelmet");
		GameRegistry.registerItem(netherdiamondchestplate = new ItemModArmor("netherdiamondchestplate", NETHERDIAMONDARMOR, 1, 1), "netherdiamondchestplate");
		GameRegistry.registerItem(netherdiamondleggings = new ItemModArmor("netherdiamondleggings", NETHERDIAMONDARMOR, 2, 2), "netherdiamondleggings");
		GameRegistry.registerItem(netherdiamondboots = new ItemModArmor("netherdiamondboots", NETHERDIAMONDARMOR, 1, 3), "netherdiamondboots");
	}
	
	public static void registerItemRenderer() {
			//STEP 3: Render your Item here
			render(ModItems.netherdiamond);
			render(ModItems.magicBeans);
			
			
			render(netherdiamondbow);
			
			render(ModItems.netherdiamondmultitool);
			render(ModItems.netherdiamondshovel);
			render(ModItems.netherdiamondhoe);
			render(ModItems.netherdiamondpickaxe);
			render(ModItems.netherdiamondsword);
			render(ModItems.netherdiamondaxe);
		

			render(ModItems.netherdiamondhelmet);
			render(ModItems.netherdiamondboots);
			render(ModItems.netherdiamondleggings);
			render(ModItems.netherdiamondchestplate);
	}
	//STEP 4: Add JSON file to assets.mod.models.item
	//STEP 5: Add texture png file to assets.mod.textures.item
	//STEP 6: Add your item's name to en_US.lang
	
	//STEP 6.5, if you are making armor, define potion effects in ItemModArmor.java
	
	//Done!
	

//==========================================================================
		//LEAVE THIS ALONE
		public static String modid = Main.MODID;
		public static void render(Item item) {
			Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(item, 0, new ModelResourceLocation(modid + ":" + item.getUnlocalizedName().substring(5), "inventory"));
		}
		public static void render(Item item, int meta, String file) {
			Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(item, meta, new ModelResourceLocation(modid + ":" + file, "inventory"));
		}

}
