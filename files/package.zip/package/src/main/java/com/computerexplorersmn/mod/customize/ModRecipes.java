package com.computerexplorersmn.mod.customize;

import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.registry.GameRegistry;

public final class ModRecipes {
	//CRAFTING RECIPES GO HERE

	public static void initCrafting() {
		GameRegistry.addRecipe(new ItemStack(ModBlocks.netherdiamondblock), 
				"SSS",
				"SSS",
				"SSS",
				'S', ModItems.netherdiamond);
		GameRegistry.addRecipe(new ItemStack(ModItems.netherdiamondaxe), 
				"SS",
				"SS",
				" S",
				'S', ModItems.netherdiamond);
		GameRegistry.addRecipe(new ItemStack(ModItems.netherdiamondpickaxe), 
				"SSS",
				" S ",
				" S ",
				'S', ModItems.netherdiamond);
		GameRegistry.addRecipe(new ItemStack(ModItems.netherdiamondhoe), 
				"SS ",
				" S ",
				" S ",
				'S', ModItems.netherdiamond);
		GameRegistry.addRecipe(new ItemStack(ModItems.netherdiamondshovel), 
				" S ",
				" S ",
				" S ",
				'S', ModItems.netherdiamond);
		GameRegistry.addRecipe(new ItemStack(ModItems.netherdiamondsword), 
				" B ",
				" B ",
				" S ", 
				'S', ModItems.netherdiamond,
				'B', ModBlocks.netherdiamondblock);
		GameRegistry.addShapelessRecipe(new ItemStack(
				ModItems.netherdiamondmultitool), ModItems.netherdiamondaxe,
				ModItems.netherdiamondpickaxe, ModItems.netherdiamondhoe,
				ModItems.netherdiamondshovel);
		
		GameRegistry.addRecipe(new ItemStack(ModItems.netherdiamondleggings), 
				"SSS",
				"S S",
				"S S",
				'S', ModItems.netherdiamond);
		GameRegistry.addRecipe(new ItemStack(ModItems.netherdiamondboots), 
				"   ",
				"S S",
				"S S",
				'S', ModItems.netherdiamond);
		GameRegistry.addRecipe(new ItemStack(ModItems.netherdiamondchestplate), 
				"S S",
				"SSS",
				"SSS",
				'S', ModItems.netherdiamond);
		GameRegistry.addRecipe(new ItemStack(ModItems.netherdiamondhelmet), 
				"   ",
				"SSS",
				"S S",
				'S', ModItems.netherdiamond);
	}
}
