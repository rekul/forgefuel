package com.computerexplorersmn.mod.customize;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.GameRegistry;

import com.computerexplorersmn.mod.framework.Main;
import com.computerexplorersmn.mod.framework.blocks.BasicBlock;
import com.computerexplorersmn.mod.framework.blocks.ModBlockOre;

public final class ModBlocks {

	//STEP 1: Declare your Block here
	public static Block netherdiamondblock;
	public static Block netherdiamondore;

	
	public static void createBlocks() {
		//STEP 2: Register your Block here
	    GameRegistry.registerBlock(netherdiamondore=new ModBlockOre("netherdiamondore", Material.rock, ModItems.netherdiamond, 2, 5), "netherdiamondore");
	    GameRegistry.registerBlock(netherdiamondblock=new BasicBlock("netherdiamondblock"), "netherdiamondblock");
	}
	
	
	public static void registerBlockRenderer() {
		//STEP3: Render your Block here
		render(ModBlocks.netherdiamondblock);
		render(ModBlocks.netherdiamondore);
	}
	//STEP 4: Add JSON file to assets.mod.blockstates
	//STEP 5: Add JSON file to assets.mod.models.block
	//STEP 6: Add JSON file to assets.mod.models.item
	//STEP 7: Add Texture png to assets.mod.textures.blocks
	//STEP 8: Add your Block's name to en_US.lang
	
	//Done!
	
	
	
	
	
	
	
	
//============================================================	
	//LEAVE THIS ALONE
	public static String modid = Main.MODID;
	public static void render(Block block) {
		Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(Item.getItemFromBlock(block), 0, new ModelResourceLocation(modid + ":" + block.getUnlocalizedName().substring(5), "inventory"));
	}


}