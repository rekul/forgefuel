package com.computerexplorersmn.mod.framework;

import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

import com.computerexplorersmn.mod.customize.ModBlocks;
import com.computerexplorersmn.mod.customize.ModItems;


/*DONT TOUCH THIS FILE, IT IS SET UP JUST THE WAY YOU NEED IT */

public class ClientProxy extends CommonProxy {

	@Override
	public void preInit(FMLPreInitializationEvent e) {
		super.preInit(e);
	}

	@Override
	public void init(FMLInitializationEvent e) {
		super.init(e);
		
		ModBlocks.registerBlockRenderer();
		ModItems.registerItemRenderer();
	}

	@Override
	public void postInit(FMLPostInitializationEvent e) {
		super.postInit(e);
	}

}
