package com.computerexplorersmn.mod.customize;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class ItemModArmor extends ItemArmor {
	//this file is where you add potion effects to your armor
	public ItemModArmor(String unlocalizedName, ArmorMaterial material, int renderIndex, int armorType) {
		super(material, renderIndex, armorType);

		this.setUnlocalizedName(unlocalizedName);
	}

	@Override
	public void onArmorTick(World world, EntityPlayer player, ItemStack itemStack) {
		//if you want a potion effect on an INDIVIDUAL piece of armor, add it in an if statement here
		if (itemStack.getItem() == ModItems.netherdiamondhelmet) {
			this.effectPlayer(player, Potion.waterBreathing, 3);
		}
		if (itemStack.getItem() == ModItems.netherdiamondchestplate) {
			this.effectPlayer(player, Potion.regeneration, 0);
		}
		if (itemStack.getItem() == ModItems.netherdiamondleggings) {
			this.effectPlayer(player, Potion.moveSpeed, 2);
		}
		if (itemStack.getItem() == ModItems.netherdiamondboots) {
			this.effectPlayer(player, Potion.jump, 2);
		}
		
		//For a SET bonus, copy the if statement bellow and edit it to your armor
		if (this.isWearingFullSet(player, ModItems.netherdiamondhelmet, ModItems.netherdiamondchestplate, ModItems.netherdiamondleggings, ModItems.netherdiamondboots)) {
			this.effectPlayer(player, Potion.digSpeed, 2);
			this.effectPlayer(player, Potion.fireResistance, 2);
		}
	}

	
	
	//LEAVE THIS ALONE
	private void effectPlayer(EntityPlayer player, Potion potion, int amplifier) {
		//Always effect for 8 seconds, then refresh
		if (player.getActivePotionEffect(potion) == null || player.getActivePotionEffect(potion).getDuration() <= 1)
			player.addPotionEffect(new PotionEffect(potion.id, 159, amplifier, true, true));
	}

	private boolean isWearingFullSet(EntityPlayer player, Item helmet, Item chestplate, Item leggings, Item boots) {
		return player.inventory.armorItemInSlot(3) != null && player.inventory.armorItemInSlot(3).getItem() == helmet
				&& player.inventory.armorItemInSlot(2) != null && player.inventory.armorItemInSlot(2).getItem() == chestplate
				&& player.inventory.armorItemInSlot(1) != null && player.inventory.armorItemInSlot(1).getItem() == leggings
				&& player.inventory.armorItemInSlot(0) != null && player.inventory.armorItemInSlot(0).getItem() == boots;
	}
}
